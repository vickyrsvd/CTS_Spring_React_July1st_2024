package com.cts.SpringCoreDemo;

import org.springframework.stereotype.Component;


public interface Address {
	
//		public abstract  Address getAddress();
}
