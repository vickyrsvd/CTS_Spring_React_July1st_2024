package com.cts.SpringCoreDemo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.cts.SpringCoreDemo")
public class App {
	public static void main(String[] args) {
		// BeanFactory,ApplicationContext
//    	Resource resource =new ClassPathResource("springconfig.xml")
//    	BeanFactory factory=new 
//	XML CONFIG
//		ApplicationContext context = new ClassPathXmlApplicationContext("springconfig.xml");
//		Employee emp = (Employee) context.getBean("emp");
//		System.out.println(emp);

//Annotation Config

		ApplicationContext context = new AnnotationConfigApplicationContext(App.class);
		Employee emp = (Employee) context.getBean("employee");
		System.out.println(emp);
		System.out.println(emp.getAdd());

	}

//	@Bean("employee")
//	public Employee getEmp() {
//		return new Employee();
//	}
}
