package com.cts.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.daolayer.DaoInterface;
@Service("service")
public class ServiceImpl implements ServiceInterface {
	@Autowired
	DaoInterface dao;

	@Override
	public String returnMessage() {

		return dao.returnMessage();
	}

}
