package com.cts.service;

public interface ServiceInterface {
	public abstract String returnMessage();

}
