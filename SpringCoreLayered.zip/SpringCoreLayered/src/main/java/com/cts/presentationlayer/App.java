package com.cts.presentationlayer;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.cts.service.ServiceInterface;

@Configuration
@ComponentScan("com.cts")
public class App {
	public static void main(String[] args) {

//Annotation Config
		ApplicationContext context = new AnnotationConfigApplicationContext(App.class);
		ServiceInterface serviceObj = (ServiceInterface) context.getBean("service");
		System.out.println(serviceObj.returnMessage());
		System.out.println(serviceObj);
	}
}
