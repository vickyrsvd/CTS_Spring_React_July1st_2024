package com.cts.daolayer;

public interface DaoInterface {
	public abstract String returnMessage();
}
