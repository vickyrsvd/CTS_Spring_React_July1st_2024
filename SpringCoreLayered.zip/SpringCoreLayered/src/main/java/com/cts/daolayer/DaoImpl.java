package com.cts.daolayer;

import org.springframework.stereotype.Repository;

@Repository
public class DaoImpl implements DaoInterface {

	@Override
	public String returnMessage() {

		return "Data Interaction is done!!!!";
	}

}
