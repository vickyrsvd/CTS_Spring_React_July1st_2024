package com.cts.mobile;

public interface Sim {

	void call();
	void browse();
	void sendSms();
	void sendMms();
}
