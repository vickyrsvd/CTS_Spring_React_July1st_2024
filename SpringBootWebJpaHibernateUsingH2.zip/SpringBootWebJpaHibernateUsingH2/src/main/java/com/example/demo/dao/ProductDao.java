package com.example.demo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.demo.entity.Product;

public interface ProductDao extends JpaRepository<Product, Integer>{

	public abstract List<Product> findByProductPriceBetween(int intialPrice,int finalPrice);

	abstract List<Product> findByProductCategory(String productCategory);
	
	
	
//	@Query("select p from Product p where p.productPrice between :1 and :2")
//	abstract List<Product> getAllProductsBetweenPrices(int intialPrice,int finalPrice);
//	@Query("select p from Product p where p.productCategory=:1")
//	abstract List<Product> getAllProductsByCategory(String productCategory);
}
