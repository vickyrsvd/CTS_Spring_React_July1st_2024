package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Product;
import com.example.demo.exceptions.ProductNotFoundException;
import com.example.demo.service.ProductService;

import jakarta.validation.Valid;

//@Controller+@ResponseBody
@RestController
@RequestMapping("/products")
public class ProductController {

	@Autowired
	ProductService service;

	@PostMapping("/addproduct") //http://localhost:8080/products/addproduct
	public String addProduct(@RequestBody @Valid Product product) {
		return service.addProduct(product);
	}

	@PutMapping("/updateproduct")//http://localhost:8080/products/updateproduct
	public String updateProduct(@RequestBody Product product) {
		return service.updateProduct(product);
	}

	@DeleteMapping("/deleteproduct/{id}")//http://localhost:8080/products/deleteproduct/1
	public String deleteProduct(@PathVariable("id") int productId) {
		return service.deleteProduct(productId);
	}

	@GetMapping("getproduct/{id}") //http://localhost:8080/products/getproduct/1
	public Product getProductById(@PathVariable("id") int productId) throws ProductNotFoundException  {
			return service.getProductById(productId);
	
	}

	@GetMapping("getproducts") //http://localhost:8080/products/getproducts
	public List<Product> getAllProducts() {
		return service.getAllProducts();
	}

	@GetMapping("getproductsbetween/{iprice}/{fprice}")////http://localhost:8080/products/getproductsbetween/1000/2000
	public List<Product> getAllProductsBetweenPrices(@PathVariable("iprice") int intialPrice,
			@PathVariable("fprice") int finalPrice) {
		return service.getAllProductsBetweenPrices(intialPrice, finalPrice);
	}

	@GetMapping("getproductsbycategory/{category}")//  http://localhost:8080/products/getproductsbycategory/groceries
	public List<Product> getproductsbetween(@PathVariable("category")String productCategory) {
		return service.getAllProductsByCategory(productCategory);
	}
	
	//controller level exception handling 
//	@ResponseStatus(value=HttpStatus.NOT_FOUND, 
//			reason="Product with this id not present")
//	@ExceptionHandler(ProductNotFoundException.class)
//	public void handler() {
//		
//	}

}
