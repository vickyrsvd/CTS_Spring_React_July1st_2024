package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.ProductDao;
import com.example.demo.entity.Product;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class ProductServiceImpl implements ProductService {
	@Autowired
	ProductDao dao;

	@Override
	public String addProduct(Product product) {

		return dao.addProduct(product);
	}

	@Override
	public String updateProduct(Product product) {

		return dao.updateProduct(product);
	}

	@Override
	public String deleteProduct(int productId) {

		return dao.deleteProduct(productId);
	}

	@Override
	public Product getProductById(int productId) {

		return dao.getProductById(productId);
	}

	@Override
	public List<Product> getAllProducts() {

		return dao.getAllProducts();
	}

	@Override
	public List<Product> getAllProductsBetweenPrices(int intialPrice, int finalPrice) {

		return dao.getAllProductsBetweenPrices(intialPrice, finalPrice);
	}

	@Override
	public List<Product> getAllProductsByCategory(String productCategory) {

		return dao.getAllProductsByCategory(productCategory);
	}

}
