package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.ProductDao;
import com.example.demo.entity.Product;
import com.example.demo.exceptions.ProductNotFoundException;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class ProductServiceImpl implements ProductService {
	@Autowired
	ProductDao dao;

	@Override
	public String addProduct(Product product) {
			dao.save(product);
		return "Product Saved Successfully" ;
	}

	@Override
	public String updateProduct(Product product) {
		dao.save(product);
		return "Product Updated Successfully" ;
	}

	@Override
	public String deleteProduct(int productId) {
		dao.deleteById(productId);
		return "Product Deleted ";
	}

	@Override
	public Product getProductById(int productId) throws ProductNotFoundException {
			Optional<Product>optional=	dao.findById(productId);
			if(optional.isPresent())
				return optional.get();
			else
				throw new ProductNotFoundException("Invalid Product Id ....");
	}

	@Override
	public List<Product> getAllProducts() {

		return dao.findAll();
	}

	@Override
	public List<Product> getAllProductsBetweenPrices(int intialPrice, int finalPrice) {

		return dao.findByProductPriceBetween(intialPrice, finalPrice);
	}

	@Override
	public List<Product> getAllProductsByCategory(String productCategory) {

		return dao.findByProductCategory(productCategory);
	}

}
