package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Product;

public interface ProductService {
	abstract String addProduct(Product product);

	abstract String updateProduct(Product product);

	abstract String deleteProduct(int productId);

	abstract Product getProductById(int productId);

	abstract List<Product> getAllProducts();

	abstract List<Product> getAllProductsBetweenPrices(int intialPrice,int finalPrice);

	abstract List<Product> getAllProductsByCategory(String productCategory);
}
