import React from 'react';
  //functional component
 //function Component2(props){} 
 //props are imuttable
const Component2 = (props) => {
    return (
        <div className="main-cointainer">
            <h2>Compnent2</h2> 
              
            <p>{props.data1} </p>
            {/* <p>{props.data1='mahesh'}</p> */}
            {/* <p>{props.data1} </p> */}
        </div>
    )
}
  
export default Component2;