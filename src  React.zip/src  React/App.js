import './App.css';
import React from 'react'
import Component2 from './Component2';
import Employee from './Employee';
// import Registration from './Registration/Registration';
class App extends React.Component
{
  constructor(){
    super()
   this.state={data:"default state"}//defining the state of a class component
    }    
    changeState = () => {  
      this.setState({data:"am state from parent component"}); 
         }; //updating state of a component
    render(){   
      return (     
          <div className="App">  
      {/* <Registration></Registration> */}
          
         <Employee></Employee>
              <Component2 data1={this.state.data} />   
              <div className="main-cointainer">
                  <h2>Compnent1</h2> 
        <button  onClick={this.changeState} type="button"> Send state</button>    
              </div>   
          </div>   
      );          }}
export default App;
