package com.cap.dao;

import java.util.List;



import com.cap.entity.Account;
import com.cap.entity.Transaction;

public interface AccountDao {
	public abstract int createAccount(Account emp); // persist ,merge,remove

	public abstract Account getAccountDetails(int empId);// find

	public abstract int withdrawAmuont(int accNo, int amountToWithdraw);// will return updated balance

	public abstract int depositAmount(int accNo, int amountToDeposit);// will return updated balance

	public abstract int transferAmount(int fromAccNo, int toAccNo, int amountToTransfer);// will return updated balance

	public abstract void commitTransaction();// getTransaction().commit()

	public abstract List<Transaction> printTransactions(int accNo);

	public abstract void beginTransaction();// getTransaction().begin()
}
