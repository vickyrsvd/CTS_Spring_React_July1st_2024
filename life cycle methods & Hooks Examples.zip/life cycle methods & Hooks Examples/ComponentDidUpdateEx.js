import React from 'react';
//updating phase
class ComponentDidUpdateEx extends React.Component {
  constructor(props) {
    console.log(props.name)
    super();
    this.state = {
      count: 0,
    };
  }
  // This method will be called when the "Increment" button is clicked
  handleIncrement = () => {
    this.setState({ count: this.state.count + 1 });
  };
  // componentDidUpdate is called after the component updates
  componentDidUpdate(prevProps, prevState) {
    // You can access the previous props and state here
    console.log('Component updated : Props :'+prevProps.name);
    console.log('Previous state:', prevState);
    console.log('Current state:', this.state);
  }
  render() {
    return (
      <div>
        <h1>Counter</h1>
        <p>Count: {this.state.count}</p>
        <button onClick={this.handleIncrement}>Increment</button>
      </div>
    );
  }
}

export default ComponentDidUpdateEx;