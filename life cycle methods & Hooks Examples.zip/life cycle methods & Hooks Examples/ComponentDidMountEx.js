import React from 'react';
class ComponentDidMountEx extends React.Component {
  constructor() {
    console.log("from constructor")
    super();
    this.state = {
      data: null,};
    }
  componentWillMount(){
  console.log("will mount")
  }
  componentDidMount() {
    console.log("did mount")
    setTimeout(() => {
      const fetchedData = 'This data was fetched after mounting.';
      this.setState({ data: fetchedData });
    }, 5000); // Simulate a 5-seconds delay
  }
  render() {
    return (
      <div>
        <h1>componentDidMount Example</h1>
        {this.state.data ? (
          <p>Data: {this.state.data}</p>
        ) : (
          <p>Loading data...</p>
        )}
      </div>
    );
  }
}

export default ComponentDidMountEx;
//fcc reference